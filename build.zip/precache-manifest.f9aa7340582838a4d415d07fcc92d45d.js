self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c26acd326fac0af14b187fec076d6d0a",
    "url": "/telefonia/index.html"
  },
  {
    "revision": "de5373dcb968dd28bc20",
    "url": "/telefonia/static/css/2.fb346933.chunk.css"
  },
  {
    "revision": "f18fd8d1afa45e3c1b95",
    "url": "/telefonia/static/css/main.ce734c4c.chunk.css"
  },
  {
    "revision": "de5373dcb968dd28bc20",
    "url": "/telefonia/static/js/2.8f30321e.chunk.js"
  },
  {
    "revision": "5e9b6f5c16b720e8a86875f97734673e",
    "url": "/telefonia/static/js/2.8f30321e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f18fd8d1afa45e3c1b95",
    "url": "/telefonia/static/js/main.10d7b99f.chunk.js"
  },
  {
    "revision": "9b140b10492a5b2a52b3",
    "url": "/telefonia/static/js/runtime-main.3d165309.js"
  },
  {
    "revision": "02d3313b75dd29308fcef9b22f4170b0",
    "url": "/telefonia/static/media/AvenirNextLTPro-Medium.02d3313b.woff"
  },
  {
    "revision": "13b7ac48daa93d9c8097a18973b6fade",
    "url": "/telefonia/static/media/AvenirNextLTPro-Medium.13b7ac48.eot"
  },
  {
    "revision": "1f781518457a519928b18bcdaa6c60d6",
    "url": "/telefonia/static/media/AvenirNextLTPro-Medium.1f781518.otf"
  },
  {
    "revision": "1f781518457a519928b18bcdaa6c60d6",
    "url": "/telefonia/static/media/AvenirNextLTPro-Medium.1f781518.svg"
  },
  {
    "revision": "967e215fe51db182c922a154b747934d",
    "url": "/telefonia/static/media/AvenirNextLTPro-Medium.967e215f.ttf"
  },
  {
    "revision": "17c770a6d3156ac2a3038b6f7dbdc545",
    "url": "/telefonia/static/media/Avenir_Light.17c770a6.woff"
  },
  {
    "revision": "6ff7532b27d4d7f84d14462d92131d14",
    "url": "/telefonia/static/media/Avenir_Light.6ff7532b.eot"
  },
  {
    "revision": "7490173f36be6e772b11268ad5894cb9",
    "url": "/telefonia/static/media/Avenir_Light.7490173f.ttf"
  },
  {
    "revision": "1dec2fc3b39286cceecda8f76f42dfb0",
    "url": "/telefonia/static/media/Avenir_Next_Bold.1dec2fc3.ttf"
  },
  {
    "revision": "72bcb0fd15f1a3bc12f73771a6fe93e9",
    "url": "/telefonia/static/media/Avenir_Next_Bold.72bcb0fd.eot"
  },
  {
    "revision": "a951ce08b9abeb7ccd13dd3dcad5260a",
    "url": "/telefonia/static/media/Avenir_Next_Bold.a951ce08.woff"
  },
  {
    "revision": "c5f973638df1825b516216f8e6dc1bfb",
    "url": "/telefonia/static/media/Avenir_Next_Bold.c5f97363.otf"
  },
  {
    "revision": "c5f973638df1825b516216f8e6dc1bfb",
    "url": "/telefonia/static/media/Avenir_Next_Bold.c5f97363.svg"
  },
  {
    "revision": "9eb63a416b09391bbdfec60f619ea204",
    "url": "/telefonia/static/media/Avenir_Next_Demi_Bold.9eb63a41.eot"
  },
  {
    "revision": "a5fc94882b7da6bc2ee4cc0a501acaaa",
    "url": "/telefonia/static/media/Avenir_Next_Demi_Bold.a5fc9488.ttf"
  },
  {
    "revision": "d334d81adb33e8ec37060fba54bcd45d",
    "url": "/telefonia/static/media/Avenir_Next_Demi_Bold.d334d81a.otf"
  },
  {
    "revision": "d334d81adb33e8ec37060fba54bcd45d",
    "url": "/telefonia/static/media/Avenir_Next_Demi_Bold.d334d81a.svg"
  },
  {
    "revision": "dfbb7abbc459520dca8453603b0534c6",
    "url": "/telefonia/static/media/Avenir_Next_Demi_Bold.dfbb7abb.woff"
  },
  {
    "revision": "7553bda6c46d132390fbecc4cb2cc3fc",
    "url": "/telefonia/static/media/Avenir_Next_Regular.7553bda6.ttf"
  },
  {
    "revision": "8fc59979fd019dee30db0fdb3604eb11",
    "url": "/telefonia/static/media/Avenir_Next_Regular.8fc59979.woff"
  },
  {
    "revision": "d917ade0a31f9673dc7c0236251c714f",
    "url": "/telefonia/static/media/Avenir_Next_Regular.d917ade0.eot"
  },
  {
    "revision": "ed09ebb0951c2de0f212372ba018b581",
    "url": "/telefonia/static/media/Avenir_Next_Regular.ed09ebb0.otf"
  },
  {
    "revision": "ed09ebb0951c2de0f212372ba018b581",
    "url": "/telefonia/static/media/Avenir_Next_Regular.ed09ebb0.svg"
  },
  {
    "revision": "95b526f948bb6fb552f4e5e29c62b6db",
    "url": "/telefonia/static/media/automovil.95b526f9.svg"
  },
  {
    "revision": "1c50172e81969e3d8910e65bc6eed33c",
    "url": "/telefonia/static/media/correo.1c50172e.svg"
  },
  {
    "revision": "19c0b45d568d3346b8b35f03e2b8da07",
    "url": "/telefonia/static/media/creditoElektra.19c0b45d.svg"
  },
  {
    "revision": "94c98a913573e1aea4b8a4f4cf201962",
    "url": "/telefonia/static/media/datos.94c98a91.svg"
  },
  {
    "revision": "89b89deaa53289bab930bf6e457341eb",
    "url": "/telefonia/static/media/dostaVista.89b89dea.svg"
  },
  {
    "revision": "d9e6d2c59380c9824712db21782024e0",
    "url": "/telefonia/static/media/facebook.d9e6d2c5.svg"
  },
  {
    "revision": "87c8233b8bbb38be2f6f38350feb2e8b",
    "url": "/telefonia/static/media/instagram.87c8233b.svg"
  },
  {
    "revision": "be6d119efae89d4ecaac2fd29d24ca01",
    "url": "/telefonia/static/media/logo.be6d119e.png"
  },
  {
    "revision": "38e5fd3e190aa320b68f585906c3887a",
    "url": "/telefonia/static/media/logo_elektra_dos.38e5fd3e.svg"
  },
  {
    "revision": "be929b315fc2ff23b7078562815179f2",
    "url": "/telefonia/static/media/logo_oui.be929b31.svg"
  },
  {
    "revision": "99a6e870ba1fdb1131fe1318d8d0d801",
    "url": "/telefonia/static/media/qr.99a6e870.jpg"
  },
  {
    "revision": "7824820e72a6e14b17859d73bc60a388",
    "url": "/telefonia/static/media/slider1.7824820e.png"
  },
  {
    "revision": "7fb8e0e9d96329ba5e8f93c0d165ae64",
    "url": "/telefonia/static/media/slider10.7fb8e0e9.jpeg"
  },
  {
    "revision": "e1ba7cd63a4657828e40fad845be962a",
    "url": "/telefonia/static/media/slider11.e1ba7cd6.jpeg"
  },
  {
    "revision": "5a3dfa3885303f15616f72b9cc5222a3",
    "url": "/telefonia/static/media/slider12.5a3dfa38.jpeg"
  },
  {
    "revision": "8e214afba638337711f99a37d8faa32f",
    "url": "/telefonia/static/media/slider2.8e214afb.png"
  },
  {
    "revision": "496ef09c50872f32bdedf902a2991510",
    "url": "/telefonia/static/media/slider3.496ef09c.png"
  },
  {
    "revision": "7f9b5123cc15a6f7c86876e02e7dd711",
    "url": "/telefonia/static/media/slider4.7f9b5123.jpeg"
  },
  {
    "revision": "5543fac95628f10c9921478f55a55f86",
    "url": "/telefonia/static/media/slider5.5543fac9.jpeg"
  },
  {
    "revision": "469e9c2149ef99fcde4f865cf904f200",
    "url": "/telefonia/static/media/slider6.469e9c21.jpeg"
  },
  {
    "revision": "e55533e0b67fbfa1cb46fdb60d531a2f",
    "url": "/telefonia/static/media/slider7.e55533e0.jpeg"
  },
  {
    "revision": "b13381bf831ad6c931342e00970cd47f",
    "url": "/telefonia/static/media/slider8.b13381bf.jpeg"
  },
  {
    "revision": "bdf5993d117dbf3e6314436f6e245444",
    "url": "/telefonia/static/media/slider9.bdf5993d.jpeg"
  },
  {
    "revision": "779d0464fb1da2f10087037687c64a82",
    "url": "/telefonia/static/media/snapchat.779d0464.svg"
  },
  {
    "revision": "d285b7ec65d411d63aea4b0072a542ce",
    "url": "/telefonia/static/media/telefono.d285b7ec.svg"
  },
  {
    "revision": "895fa30604161a99f9e9c7538f6de09e",
    "url": "/telefonia/static/media/twitter.895fa306.svg"
  },
  {
    "revision": "ae5118607aa4ae8989eb4e6c4fd71bb2",
    "url": "/telefonia/static/media/whatsapp.ae511860.svg"
  }
]);